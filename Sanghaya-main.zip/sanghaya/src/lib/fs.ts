"use client";
import FS from "@isomorphic-git/lightning-fs";

export const fs = new FS("adorable-fs");
