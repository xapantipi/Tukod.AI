import { anthropic } from "@ai-sdk/anthropic";

export const ANTHROPIC_MODEL = anthropic("claude-sonnet-4-20250514");
